class Profile < ActiveRecord::Base
end
